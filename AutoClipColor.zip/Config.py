# config.py

# 1. Add any root hard drive folders you want to sync into DaVinci Resolve.
FOLDERS_TO_SYNC = [
    r"D:\RAW",
    r"G:\360"
]

# 2. Match your camera names or keywords to your preferred DaVinci Resolve colors.
# Remember: Specific models go at the top, generic words go at the bottom.
CAMERA_KEYWORDS = {
    "insta360": "Yellow",
    "pocket 4p": "Violet",
    "dji pocket 3": "Purple",
    "air 2s": "Tan",
    "s25 ultra": "Chocolate",
    "a7siii": "Orange",
    
    # Generic or short triggers last
    "360": "Pink",
    "sony": "Orange",
    "canon": "Blue",
    "gopro": "Navy"
}